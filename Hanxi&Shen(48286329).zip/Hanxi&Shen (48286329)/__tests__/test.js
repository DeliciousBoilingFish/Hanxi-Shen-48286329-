import DataFrame from '../translink-parser/dataframe';
import fs from 'fs';


jest.mock('fs');

describe('DataFrame', () => {
    let dataFrame;

    beforeEach(() => {
        dataFrame = new DataFrame();
    });

    test('should load CSV file correctly', () => {
        const mockCSV = `route_id,service_id,trip_id,trip_headsign,direction_id,block_id,shape_id
R348-3303,ATS_HBL 24-35875,27541645-ATS_HBL 24-35875,"Northgate station",0,,R3480178
R348-3303,ATS_HBL 24-35875,27541646-ATS_HBL 24-35875,"Northgate station",0,,R3480178
R348-3303,ATS_HBL 24-35875,27541647-ATS_HBL 24-35875,"Northgate station",0,,R3480178
R348-3303,ATS_HBL 24-35875,27541648-ATS_HBL 24-35875,"Northgate station",0,,R3480178
R348-3303,ATS_HBL 24-35875,27541649-ATS_HBL 24-35875,"Northgate station",0,,R3480178`;
        fs.readFileSync.mockReturnValue(mockCSV);

        const result = dataFrame.loadCSV('mock.csv');
        
        expect(result).toEqual([
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541645-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541646-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541647-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541648-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541649-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' }
        ]);
    });

    test('should return an empty array if CSV is empty', () => {
        const mockCSV = `route_id,service_id,trip_id,trip_headsign,direction_id,block_id,shape_id\n`;
        fs.readFileSync.mockReturnValue(mockCSV);

        const result = dataFrame.loadCSV('mock.csv');
        
        expect(result).toEqual([]);
    });

    test('should handle CSV with extra spaces', () => {
        const mockCSV = ` route_id , service_id , trip_id , trip_headsign , direction_id , block_id , shape_id 
 R348-3303 , ATS_HBL 24-35875 , 27541645-ATS_HBL 24-35875 , "Northgate station" , 0 , , R3480178 
 R348-3303 , ATS_HBL 24-35875 , 27541646-ATS_HBL 24-35875 , "Northgate station" , 0 , , R3480178 
 R348-3303 , ATS_HBL 24-35875 , 27541647-ATS_HBL 24-35875 , "Northgate station" , 0 , , R3480178 
 R348-3303 , ATS_HBL 24-35875 , 27541648-ATS_HBL 24-35875 , "Northgate station" , 0 , , R3480178 
 R348-3303 , ATS_HBL 24-35875 , 27541649-ATS_HBL 24-35875 , "Northgate station" , 0 , , R3480178 `;
        fs.readFileSync.mockReturnValue(mockCSV);

        const result = dataFrame.loadCSV('mock.csv');
        
        expect(result).toEqual([
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541645-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541646-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541647-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541648-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' },
            { route_id: 'R348-3303', service_id: 'ATS_HBL 24-35875', trip_id: '27541649-ATS_HBL 24-35875', trip_headsign: 'Northgate station', direction_id: '0', block_id: '', shape_id: 'R3480178' }
        ]);
    });
});
