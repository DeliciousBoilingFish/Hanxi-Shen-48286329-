import fs from 'fs';

class DataFrame {
    // Load CSV file as a dataframe
    loadCSV(filePath) {
        const data = fs.readFileSync(filePath, 'utf-8');
        
        // Split data into rows and filter out empty rows
        const rows = data.split('\n').filter(row => row.trim() !== '');
        
        // Get the header row and trim the spaces from each header
        const headers = rows.shift().split(',').map(header => header.trim());
        
        return rows.map(row => {
            const obj = {};
            
            // Split each line and trim spaces and remove quotes from each value
            const values = row.split(',').map(value => value.trim().replace(/^"|"$/g, ''));

            headers.forEach((header, index) => {
                obj[header] = values[index] || ''; // If a column is missing a value, an empty string is assigned
            });

            return obj;
        });
    }


}

export default DataFrame;
