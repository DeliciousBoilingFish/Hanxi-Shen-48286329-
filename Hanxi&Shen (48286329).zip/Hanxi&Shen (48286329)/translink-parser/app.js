import prompt from 'prompt';
import TranslinkParser from './translink-parser.js';

prompt.message = '';
prompt.delimiter = '';

function getInputWithValidation(promptMessage, pattern, errorMessage) {
    return new Promise((resolve, reject) => {
        prompt.get([promptMessage], function (err, result) {
            if (err) {
                return reject(err);
            }

            let input = result[promptMessage];
            if (pattern.test(input)) {
                return resolve(input);
            } else {
                console.error(errorMessage);
                getInputWithValidation(promptMessage, pattern, errorMessage)
                    .then(resolve)
                    .catch(reject);
            }
        });
    });
}


async function main() {
    console.log("Welcome to the South East Queensland Route Planner!");

    const parser = new TranslinkParser();
    parser.loadStaticData();  //Loading static data
    await parser.startRealTimeDataUpdater(5);


    console.log("Parser initialized with live data.");
    const route = await getInputWithValidation("What Bus Route would you like to take? ", /.*/, "");
    const stopsForRoute = parser.getStopsForRoute(route);

    if (stopsForRoute.length === 0) {
        console.log(`No stops found for route ${route}.`);
    } else {
        console.log(`Stops for route ${route}:`);
        stopsForRoute.forEach(stop => {
            console.log(`${stop.stop_sequence}. ${stop.stop_name}`);
        });
    }

   


    const stopPattern = /^\d+-\d+$/;
    const startEndStops = await getInputWithValidation("What is your start and end stop on the route? (format: start_stop-end_stop) ", stopPattern, "Please follow the format and enter a valid number for the stop");

    const datePattern = /^\d{4}-\d{2}-\d{2}$/;
    const date = await getInputWithValidation("What date will you take the route? (YYYY-MM-DD) ", datePattern, "Incorrect date format. Please use YYYY-MM-DD");

    const timePattern = /^\d{2}:\d{2}$/;
    const time = await getInputWithValidation("What time will you leave? (HH:mm) ", timePattern, "Incorrect time format. Please use HH:mm");

    const routeInfo = parser.getLiveInfo(routeShortName, startEndStops, date, time);
    console.table(routeInfo);

}

async function runApp() {
    let keepRunning = true;

    while (keepRunning) {
        await main();

        const validOptions = /^(y|yes|n|no)$/i;
        let userResponse = await getInputWithValidation("Would you like to search again? (y, yes, n, no): ", validOptions, "Please enter a valid option.");

        if (/^(n|no)$/i.test(userResponse)) {
            console.log("Thanks for using the Route tracker");
            keepRunning = false;
        }
    }
}

prompt.start();
runApp();
