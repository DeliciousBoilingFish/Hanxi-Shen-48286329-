import fs from 'fs';
import fetch from 'node-fetch';
import csv from 'csv-parser';
import DataFrame from './dataframe.js';   

class TranslinkParser {
    constructor() {
        this.staticDataPath = './static-data/';
        this.cachedDataPath = './cached-data/';
        this.dataFrame = new DataFrame();
    }

    // Loading static data
    loadStaticData() {
        this.stops = this.dataFrame.loadCSV(this.staticDataPath + 'stops.txt');
        this.routes = this.dataFrame.loadCSV(this.staticDataPath + 'routes.txt');
        this.trips = this.dataFrame.loadCSV(this.staticDataPath + 'trips.txt');
        this.stop_times = this.dataFrame.loadCSV(this.staticDataPath + 'stop_times.txt');
        this.calendar = this.dataFrame.loadCSV(this.staticDataPath + 'calendar.txt');
        this.calendar_dates = this.dataFrame.loadCSV(this.staticDataPath + 'calendar_dates.txt');
        console.log('Static data loaded.');
        /*console.time('Build Route Details');
        this.routesWithDetails = this.buildRouteDetails();
        console.log('First Route with Details:', this.routesWithDetails[0]);
        console.timeEnd('Build Route Details');*/
    }

    async RealTimeData() {
        try {
            const { tripUpdates, vehiclePositions } = await this.loadRealTimeData();
            this.tripUpdates = tripUpdates;
            this.vehiclePositions = vehiclePositions;
            console.log('Live data loaded.');

        } catch (error) {
            console.error('Failed to load live data:', error);
        }
    }

    async startRealTimeDataUpdater(intervalMinutes = 5) {
        // Initial loading
        await this.RealTimeData();

        // Update the cache every intervalMinutes minutes
        setInterval(() => {
            this.RealTimeData();
        }, intervalMinutes * 60 * 1000);
    }

    async loadRealTimeData() {
        const tripUpdates = await this.fetchAndCacheData('http://127.0.0.1:5343/gtfs/seq/trip_updates.json', 'trip_updates.json');
        const vehiclePositions = await this.fetchAndCacheData('http://127.0.0.1:5343/gtfs/seq/vehicle_positions.json', 'vehicle_positions.json');
        return { tripUpdates, vehiclePositions };   
       }

    async fetchAndCacheData(url, cacheFilename) {
        const cacheFilePath = this.cachedDataPath + cacheFilename;
        let data;

        try {
            if (fs.existsSync(cacheFilePath)) {
                // Reading data from cache
                data = JSON.parse(fs.readFileSync(cacheFilePath, 'utf-8'));
            } else {
                // Get data from the API
                const response = await fetch(url);
                if (!response.ok) {
                    throw new Error(`Failed to fetch data from ${url}: ${response.statusText}`);
                }
                data = await response.json();  // Get JSON data directly
                // Cache data locally
                fs.writeFileSync(cacheFilePath, JSON.stringify(data));
            }
        } catch (error) {
            console.error(`Error fetching or caching data for ${url}:`, error);
            throw error; 
        }

        return data;
    }

    getStopsForRoute(routeId,directionId = 0) {
        // Filter out trip data that matches routeId
        const selectedRoute = this.routes.find(route => route.route_short_name === routeId);
        const relevantTrips = this.trips.filter(trip => trip.route_id === selectedRoute.route_id&&Number(trip.direction_id)===directionId);
        if (relevantTrips.length === 0) {
            console.error(`No trips found for route ${routeId} with direction_id ${directionId}.`);
            return [];
        }
        // Get all stop_details and append stop_name
        const stop_details = this.stop_times.map(stop_time => {
            const stop = this.stops.find(s => s.stop_id === stop_time.stop_id); 
            return {
                ...stop_time,
                stop_name: stop ? stop.stop_name : "Unknown"  // Check if stop exists and make sure there are no errors when accessing stop_name
            };
        });
    
        const seenStopsequence = new Set();
        const stopsForRoute = [];
        
    
        // Connect stops to trips and filter out stops corresponding to routeId
        for (const stop of stop_details) {
            if (relevantTrips.some(trip => trip.trip_id === stop.trip_id)) {

                if (seenStopsequence.has(stop.stop_sequence)) {
                    break;  // Find the first repeated stop_name and stop processing
                }
                // Add stop_name to Set and the resulting list
                // Add stop information to the results list
                seenStopsequence.add(stop.stop_sequence);
                stopsForRoute.push({
                    stop_sequence: stop.stop_sequence,  // Use stop_sequence as the sort order
                    stop_id: stop.stop_id,
                    stop_name: stop.stop_name
                });
    
                
            }
        }  
        // Returns a list containing the stop_sequence, stop ID, and stop name
        return stopsForRoute;
    }
    

    // Add date conversion function
    convertDateToYYYYMMDD(dateString) {
        return dateString.replace(/-/g, '');
    }

    convertToTimestamp(date, time) {
        return new Date(`${date}T${time}Z`).getTime() / 1000;
    }

    convertDateToNumber(date) {
        return parseInt(date, 10);
    }

   timeToSeconds(timeString) {
        const [hours, minutes, seconds] = timeString.split(':').map(Number);
        return hours * 3600 + minutes * 60 + seconds;
    }
    
    estimatedTravelTime = (startStopTime, endStopTime) => {
        if (startStopTime && endStopTime) {
            const startTimeInSeconds = this.timeToSeconds(startStopTime);
            const endTimeInSeconds = this.timeToSeconds(endStopTime);
    
            const timeDifferenceInSeconds = endTimeInSeconds - startTimeInSeconds;
            const timeDifferenceInMinutes = Math.floor(timeDifferenceInSeconds / 60); // Convert to minutes
    
            return `${timeDifferenceInMinutes} mins`;
        } else {
            return "N/A";
        }
    };
    
    // Get the day of the week corresponding to a date
    getDayOfWeek(dateString) {
        const date = new Date(
            parseInt(dateString.substring(0, 4)),  
            parseInt(dateString.substring(4, 6)) - 1, 
            parseInt(dateString.substring(6, 8))  
        );
    
        return date.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    }
    
    

    getRouteInfo(route_name, startEndStops, date, time) {
        // Parse the startEndStops input by the user to get the start and end point numbers
        const [startStopIndex, endStopIndex] = startEndStops.split('-').map(Number);
        const directionId = startStopIndex < endStopIndex ? 0 : 1;
        const dateString = this.convertDateToYYYYMMDD(date);
        const currentDateNumber = this.convertDateToNumber(dateString);
        const dayOfWeek = this.getDayOfWeek(dateString);
        // Find the corresponding route from routesWithDetails
        const selectedRoute = this.routes.find(route => route.route_short_name === route_name);
        const selectedtrip =this.trips.filter(trip => trip.route_id === selectedRoute.route_id);

        if (!selectedRoute) {
            console.error("No matching route found.");
            return [];
        }

        // Get all stops for this route
        const stopsForRoute = this.getStopsForRoute(route_name,directionId);


        // Find the stop_id of startStop and endStop according to the number
        const startStop = stopsForRoute.find(stop => Number(stop.stop_sequence) === startStopIndex);
        if (!startStop) {
            console.error(`Start stop with ID ${startStopIndex} not found.`);
            return []; 
        }

        const endStop = stopsForRoute.find(stop => Number(stop.stop_sequence) === endStopIndex);
        if (!endStop) {
            console.error(`End stop with ID ${endStopIndex} not found.`);
            return []; 
        }
        const relevantTrips = selectedtrip.filter(trip => {
            // Filter services by date and service ID
            if(Number(trip.direction_id)!==directionId){
                return false;
            }
            const serviceOnDate = this.calendar.find(cd => cd.service_id === trip.service_id);

            if (!serviceOnDate) {
                return false;  //If no matching service is found, filter out the trip
            }

            const daysOfWeek = ["sunday","monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
            const dayField = daysOfWeek[dayOfWeek];

            // Check if there is service on that day of the week
            if (serviceOnDate[dayField] !== '1') {
                return false;  // If there is no service on that day, filter out the trip
            }

            const calendarDate = this.calendar_dates.find(cd => cd.service_id === trip.service_id && cd.date === dateString);

            // If calendarDate is found and exception_type is 1, keep the trip
            if (calendarDate && calendarDate.exception_type === '1') {
                return true;
            }

            // If a calendarDate is found and exception_type is 2, remove the trip
            if (calendarDate && calendarDate.exception_type === '2') {
                return false;
            }

            // Convert the calendar's start_date and end_date to numeric format
            const startDateNumber = this.convertDateToNumber(serviceOnDate.start_date);
            const endDateNumber = this.convertDateToNumber(serviceOnDate.end_date);

            // Checks if the current date is between start_date and end_date
            if (currentDateNumber < startDateNumber || currentDateNumber > endDateNumber) {
                return false;  // If it is not in the range, filter out the trip
            }
            
        
            // Find start_stop that meets the conditions
            const start_stop = this.stop_times.find(sd => 
                sd.trip_id === trip.trip_id &&
                sd.stop_id === startStop.stop_id &&
                this.timeToSeconds(sd.arrival_time) >= this.timeToSeconds(time) && 
                this.timeToSeconds(sd.arrival_time) <= (this.timeToSeconds(time) + 10 * 60)
            );
            
        

            if (!start_stop) {
                return false;
            }
        
            // Find end_stop
            const end_stop = this.stop_times.find(sd => 
                sd.trip_id === trip.trip_id && 
                sd.stop_id === endStop.stop_id
            );
            
        
            if (!end_stop) {
                return false;
            }
        
            // Append the found start_stop and end_stop to trip
            trip.start_stop = start_stop;
            trip.end_stop = end_stop;
        
            return true; 
        }).map(trip => {
            // Returns a trip containing start_stop and end_stop information
            return {
                ...trip,
                arrival_time: trip.start_stop.arrival_time,
                end_time: trip.end_stop.arrival_time
            };
        });
            
       if (relevantTrips.length === 0) {
            console.error("No trips found for the specified date.");
            return [];
        }
    
        // Generate output data
        const outputData = relevantTrips.map(trip => {
            
            return {
                "Route Short Name": selectedRoute.route_short_name,
                "Route Long Name": selectedRoute.route_long_name,
                "Trip ID": trip.trip_id,
                "Start Stop ID": trip.start_stop.stop_id,
                "Service ID": trip.service_id,
                "Heading Sign": trip.trip_headsign,
                "Scheduled Arrival Time": trip.arrival_time,
                "Estimated Travel Time": this.estimatedTravelTime(trip.arrival_time, trip.end_time) 
           };
         });


         return outputData;
    }
    
    TimestamptoTime(timestamp) {
        const date = new Date(timestamp * 1000);
    
        // Convert a date to a Brisbane time string and extract only the time portion
        const brisbaneTimeString = date.toLocaleTimeString("en-AU", { timeZone: "Australia/Brisbane" });
    
        return brisbaneTimeString;
    }
    
    getLiveInfo(routeShortName, startENDStops, date, time) {

    const routeInfo = this.getRouteInfo(routeShortName, startENDStops, date, time);
    
    if (!this.tripUpdates || !this.vehiclePositions) {
        console.error("Real-time data not loaded.");
        return null;
    }

    // Convert input date and time to timestamp
    const targetTimestamp = this.convertToTimestamp(date, time);

    const results = [];

    // Traverse the route information obtained
    routeInfo.forEach(trip => {
        const tripUpdate = this.tripUpdates.entity.find(entity => entity.tripUpdate.trip.tripId === trip["Trip ID"]);
        let stopTime = null;
        let vehiclePosition = null;
    
        if (tripUpdate) {
            const stopUpdate = tripUpdate.tripUpdate.stopTimeUpdate.find(stop => stop.stopId === trip["Start Stop ID"]);
            
            // Check and get arrival or departure time
            if (stopUpdate && stopUpdate.arrival && stopUpdate.arrival.time) {
                stopTime = stopUpdate.arrival.time;
            } else if (stopUpdate && stopUpdate.departure && stopUpdate.departure.time) {
                stopTime = stopUpdate.departure.time;
            }

            if (stopTime && stopTime >= targetTimestamp && stopTime <= targetTimestamp + 10 * 60 * 1000) {
                // Look up vehicle locations and compare timestamps to find the closest vehicle location
                vehiclePosition = this.vehiclePositions.entity.reduce((closest, entity) => {
                    if (entity.vehicle.trip.tripId === trip["Trip ID"]) {
                        const vehicleTimestamp = entity.vehicle.timestamp;
                        if (!closest || Math.abs(vehicleTimestamp - stopTime) < Math.abs(closest.vehicle.timestamp - stopTime)) {
                            return entity;
                        }
                    }
                    return closest;
                }, null);
            }  else {
                stopTime = null;
            }
            
        }
        
        // Constructing the result object
        results.push({
            "routeShortName": trip["Route Short Name"],
            "routeLongName": trip["Route Long Name"],  
            "serviceId": trip["Service ID"],
            "headingSign": trip["Heading Sign"],  
            "scheduledArrivalTime": trip["Scheduled Arrival Time"],
            "liveArrivalTime": this.TimestamptoTime(stopTime) || "N/A",  
            "livePosition": vehiclePosition ? `${vehiclePosition.vehicle.position.latitude}, ${vehiclePosition.vehicle.position.longitude}` : "N/A",
            "estimatedTravelTime": trip["Estimated Travel Time"]
        });
    });
    return results;   
}



}

export default TranslinkParser;
